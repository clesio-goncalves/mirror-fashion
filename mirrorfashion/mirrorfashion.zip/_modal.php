<div class="modal fade" id="faq">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title">Perguntas frequentes</h3>
			</div>
			<div class="modal-body">
				<h4>Posso pagar com boleto?</h4>
				<p>Nope.</p>

				<h4>Qual o prazo de entrega?</h4>
				<p>28 min ou seu dinheiro de volta.</p>

				<h4>Por que só posso comprar 1 produto por vez?</h4>
				<p>Foco, meu caro, foco.</p>
			</div>

		</div>
	</div>
</div>
