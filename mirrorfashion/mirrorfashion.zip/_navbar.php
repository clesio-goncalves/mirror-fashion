<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="navbar-header">
		<a class="navbar-brand" href="index.php">Mirror Fashion</a>
		<button class="navbar-toggle" type="button"
			data-target=".navbar-collapse" data-toggle="collapse">
			<span class="glyphicon glyphicon-align-justify"></span>
		</button>
	</div>
	<ul class="nav navbar-nav collapse navbar-collapse">
		<li><a href="sobre.php"><span class="glyphicon glyphicon-home"></span> Sobre</a></li>
		<li><a href="#"><span class="glyphicon glyphicon-question-sign"></span>
				Ajuda</a></li>
		<li><a data-toggle="modal" href="#faq"><span
				class="glyphicon glyphicon-list-alt"></span> Perguntas frequentes</a></li>
		<li><a href="#"><span class="glyphicon glyphicon-bullhorn"></span>
				Entre em contato</a></li>
	</ul>
</nav>
